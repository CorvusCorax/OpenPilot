May 12, 2010
Patrick Glass

These measurements were taken with a Sparkfun 6dof IMU v4.
This device has a known issue with the magnetometer from the wireless bluetooth radio.
These samples should be used for basic algorithm testing in pitch and roll.
